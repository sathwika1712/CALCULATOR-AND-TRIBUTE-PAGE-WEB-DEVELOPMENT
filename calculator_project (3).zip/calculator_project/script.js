const inputField = document.getElementById("input");
const outputField = document.getElementById("output");
const buttons = document.querySelectorAll("button");

let currentInput = "";
let lastAnswer = "";

function updateDisplay() {
  inputField.innerText = currentInput;
}

buttons.forEach(button => {
  button.addEventListener("click", () => {
    const value = button.innerText;

    switch (value) {
      case "clear":
        currentInput = "";
        outputField.innerText = "";
        break;
      case "del":
        currentInput = currentInput.slice(0, -1);
        break;
      case "ENTER":
        try {
          const result = eval(currentInput
            .replace(/÷/g, "/")
            .replace(/x/g, "*")
            .replace(/√/g, "Math.sqrt")
            .replace(/±/g, "-"));
          outputField.innerText = result;
          lastAnswer = result;
        } catch (e) {
          outputField.innerText = "Error";
        }
        break;
      case "ans":
        currentInput += lastAnswer;
        break;
      default:
        currentInput += value;
    }

    updateDisplay();
  });
});
